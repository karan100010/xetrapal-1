#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 12:21:26 2018

@author: anandabhairav
"""

from thespian.actors import ActorSystem
ActorSystem("multiprocTCPBase")
vidhata = ActorSystem()
